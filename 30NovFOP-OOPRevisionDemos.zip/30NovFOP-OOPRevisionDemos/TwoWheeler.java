package com.gl.revision;

public class TwoWheeler extends Vehicle{
	
	String typeOfWheels;
	String handleBarType;
	
	public TwoWheeler()
	{
		super("KA05W333","2022",20000);
		typeOfWheels = "tubeless";
		handleBarType = "XYZType";
	}
	
	public void displayTwoWheelerDetails()
	{
		System.out.println("The Make is "+make);
		System.out.println("The Regn No is "+regnNo);
		System.out.println("Price is "+price);
		System.out.println("Wheel Type is "+typeOfWheels);
		System.out.println("HandleBarType "+handleBarType);
	}
	
	public static void main(String[] args)
	{
		TwoWheeler twoWheeler1 = new TwoWheeler();
		twoWheeler1.displayTwoWheelerDetails();
	}

}
