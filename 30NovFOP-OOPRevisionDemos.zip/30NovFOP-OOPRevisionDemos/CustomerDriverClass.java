package com.gl.revision;

public class CustomerDriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CustomerOrder harsha = new CustomerOrder("C001","Harsha","RTNagar","P001",1000,20);
		double orderValueOfHarsha = harsha.calculateOrderValue();
		System.out.println("The Order Value of Harsha "+orderValueOfHarsha);
		
		harsha.calculateDiscount();
		System.out.println("------------------------");
		CustomerOrder suman = new CustomerOrder();
		suman.calculateTotalCost(500, 100);
	}

}
