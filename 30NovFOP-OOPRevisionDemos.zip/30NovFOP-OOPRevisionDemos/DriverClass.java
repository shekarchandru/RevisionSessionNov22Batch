package com.gl.revision;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.displayEmployeeDetails();
		System.out.println("---------------------------------");
		Employee employee1 = new Employee("E002","Kiran Kumar","KOramangala",2000,12.34f);
		employee1.displayEmployeeDetails();
		
		System.out.println("---------------------------------");
		
		Employee employee2 = new Employee("E003","Kishan Kumar","Gandhinagar");
		employee2.displayEmployeeDetails();

	}

}
