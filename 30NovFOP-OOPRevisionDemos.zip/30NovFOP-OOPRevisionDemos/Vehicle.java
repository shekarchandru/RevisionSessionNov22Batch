package com.gl.revision;

public class Vehicle {
	
	String regnNo;
	String make;
	int price;
	
	public Vehicle()
	{
		regnNo = "KA05W119";
		make ="2020";
		price=10000;
		
	}

	public Vehicle(String regnNo, String make, int price) {
		super();
		this.regnNo = regnNo;
		this.make = make;
		this.price = price;
	}
	

}
