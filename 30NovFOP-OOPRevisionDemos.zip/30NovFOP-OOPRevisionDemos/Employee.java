package com.gl.revision;

public class Employee { 
	
	//Title CaSE OR Upper Camel Case
	// EmployeeDetails
		String employeeId; // lower camel case  
		String employeeName;
		String employeeAddress;
		int salary;
		float professionalTax;
		
		/*
		 * Parameterless Constructor
		 * Default Constructor
		 * Overloaded Constructor-with Parameters
		 */
		
		public Employee() // Parameterless Constructor
		{
			employeeId = "E001";
			employeeName = "Harsha";
			employeeAddress = "RTNagar";
			salary = 1000;
			professionalTax = 12.34f;
		}/**/
		public Employee(String employeeId,String employeeName,String employeeAddress)
		{
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.employeeAddress = employeeAddress;
			
		}
		
		//Parameterized Constructor
		public Employee(String employeeId,String employeeName,String employeeAddress,int salary,float professionalTax)
		{
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.employeeAddress = employeeAddress;
			this.salary = salary;
			this.professionalTax = professionalTax;
		}
		public void displayEmployeeDetails()
		{
			System.out.println("Employee Details are ");
			System.out.println("Employee Id : "+employeeId); // Employee Id :E001
			System.out.println("Employee Name :"+employeeName);
			System.out.println("Employee Address :"+employeeAddress);
			System.out.println("Employee Salary is :"+salary);
			System.out.println("Employee is liable for a Prof Tax of :"+professionalTax);
		}
		
		
		
}
