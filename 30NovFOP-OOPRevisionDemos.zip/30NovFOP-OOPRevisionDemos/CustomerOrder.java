package com.gl.revision;

public class CustomerOrder {
	
	String customerId;
	String customerName;
	String customerAddress;
	String productCode;
	int quantity;
	int pricePerUnit;
	double orderValue;
	
	public CustomerOrder() {
		super();
		
	}
//this - represents instance of current class
	//super.price // instance of the parent class
	//super() - constructor of the parent class
	public CustomerOrder(String customerId, String customerName, String customerAddress, String productCode,
			int pricePerUnit,int quantity) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.productCode = productCode;
		this.pricePerUnit = pricePerUnit;
		this.quantity = quantity;
	}
	
	public double calculateOrderValue()
	{
		double orderValue = quantity * pricePerUnit;
		return orderValue;
	}
	
	public void calculateDiscount()
	{
		double discount;
		double myOrderValue = calculateOrderValue();
		if( myOrderValue > 10000)
		{
			 discount = 15;
		}
		else
		{
			discount = 10;
		}
		double discountedValue =  (discount / 100) * myOrderValue;
		System.out.println("The Original Order Value "+myOrderValue);//writing results db
		System.out.println("The Discounted Order Value "+discountedValue);
		double finalOrderValue = myOrderValue - discountedValue;
		System.out.println("The Final Order Value "+finalOrderValue);
	}
	
	public void calculateTotalCost(int quantity,int pricePerUnit)
	{
		orderValue = quantity * pricePerUnit;
		
		System.out.println("Your Order Value :"+orderValue);
	}
}
