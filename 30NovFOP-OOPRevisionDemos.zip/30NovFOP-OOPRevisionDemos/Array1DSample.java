package com.gl.revision;

public class Array1DSample {

	public void populate1DArray()
	{
		int [] array1 = new int[10];
		for(int i=0;i<10;i++)
		{
			array1[i] = (i + 1) * 100;
			System.out.print(array1[i]+" ");
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Array1DSample ars = new Array1DSample();
		ars.populate1DArray();
	}

}
