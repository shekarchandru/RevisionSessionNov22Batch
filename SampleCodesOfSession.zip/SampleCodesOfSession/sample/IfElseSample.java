package com.gl.sample;

public class IfElseSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int score = 67;
		
		if (score >= 50)
		{
			System.out.println("Good Passed");
		}
		else
		{
			System.out.println("Sorry Try again");
		}

	}

}
