package com.gl.sample;

public class ForSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		for(int i=0;i<10;i++)
		{
			System.out.println("Print i is"+i);
		}

	}

}
