package com.gl.sample;

public class SwitcherSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int day;
		day = 5;
		switch(day)
		{
			case 1:
			{
				System.out.println("The Day is Monday");
				break;
			}
			case 2:
			{
				System.out.println("The Day is Tuesday");
				break;
			}
			case 3:
			{
				System.out.println("The Day is Wednesday");
				break;
			}
			case 4:
			{
				System.out.println("The Day is Thursday");
				break;
			}
			case 5:
			{
				System.out.println("The Day is Friday");
				break;
			}
			case 6:
			{
				System.out.println("The Day is Saturday");
				break;
			}
			case 7:
			{
				System.out.println("The Day is Sunday");
				break;
			}
			default:
			{
				System.out.println("The Day is to be 1-7");
				break;
			}
		
		}
		System.out.println("Switch is Over");
		

	}

}
