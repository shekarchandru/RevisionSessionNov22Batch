package com.gl.sample;

import java.util.Scanner;

public class WhilerSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String reply;// = "yes";
		Scanner scan1 = new Scanner(System.in);
	/*	while(reply.equals("yes"))
		{
			int num;
			int square;
			System.out.println("Enter a Number");
			num = scan1.nextInt();
			square = num * num;
			System.out.println("The Square of the Number "+num+" is "+square);
			System.out.println("Do You wish to continue yes/no");
			reply = scan1.next();
		}*/
		do
		{
			int num;
			int square;
			System.out.println("Enter a Number");
			num = scan1.nextInt();
			square = num * num;
			System.out.println("The Square of the Number "+num+" is "+square);
			System.out.println("Do You wish to continue yes/no");
			reply = scan1.next();
		}while(reply.equals("yes"));
		System.out.println("You are Out of Loop");

	}

}
