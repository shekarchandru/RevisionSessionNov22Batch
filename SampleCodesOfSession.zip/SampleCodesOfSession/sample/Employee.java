package com.gl.sample;
//EmployeePersonalDetails - Upper Camel Case
public class Employee {

		String employeeName; // Lower Camel Case for variables & methods
		String employeeAddress;
		int employeeSalary;
		public int calculateSalary(int basic,int hra,int cca)
		{
			int sal=0;
			sal = basic+hra+cca;
			return sal;
		}
		public void acceptDetails()
		{
			employeeName = "Harsha";
			employeeAddress = "RTNagar";
			employeeSalary = 1000;
		}
		
		public void displayEmployeeDetails()
		{
			System.out.println("Employee Name is "+employeeName);
			System.out.println("Employee Address is"+employeeAddress);
			System.out.println("Employee Salary "+employeeSalary);
		}
}
