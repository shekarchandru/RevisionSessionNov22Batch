package com.gl.sample;

public class DriverClass {
	
	public static void main(String[] args)
	{
	/*	Employee ramesh = new Employee();
		ramesh.acceptDetails();
		ramesh.displayEmployeeDetails();
		
		Employee kiran = new Employee();
		kiran.acceptDetails();
		kiran.displayEmployeeDetails();*/
		
		Employee emp1 = new Employee();
	int mySalary =	emp1.calculateSalary(1000, 250, 175);
	System.out.println("Salary is "+mySalary);
	}

}
