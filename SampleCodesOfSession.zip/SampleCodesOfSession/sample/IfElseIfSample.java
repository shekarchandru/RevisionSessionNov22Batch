package com.gl.sample;

public class IfElseIfSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int score = 45;
		if((score >= 0)&&(score <= 100))
		{
			if( (score >= 50) && (score < 60)) // && and condition
			{
				System.out.println("Good Passed ...");
			}
			else if ((score >= 60) && (score < 70))
			{
				System.out.println("VGood Secured First Class");
			}
			else if((score >= 70)&&(score <= 100))
			{
				System.out.println("Excellent Secured Distinction");
			}
			else
			{
				System.out.println("Sorry Try again");
			}
		}
		else
		{
			System.out.println("Sorry Valid Score is 0-100");
		}
		

	}

}
